package com.Ecommerce.inventory.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Ecommerce.inventory.model.Inventory;



public interface InventoryRepository  extends JpaRepository<Inventory,Long>{


	List<Inventory> findByNameIn(List<String> name);

}
