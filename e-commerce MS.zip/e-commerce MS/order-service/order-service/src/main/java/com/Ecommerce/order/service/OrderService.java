package com.Ecommerce.order.service;

import java.util.Arrays;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.Ecommerce.order.dto.InventoryResponse;
import com.Ecommerce.order.dto.OrderItemsdto;
import com.Ecommerce.order.dto.OrderRequest;
import com.Ecommerce.order.event.OrderPlacedEvent;
import com.Ecommerce.order.model.Order;
import com.Ecommerce.order.model.OrderItems;
import com.Ecommerce.order.repository.OrderRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional

public class OrderService {
	
	@Autowired
	private OrderItemsdto oid;
	@Autowired
	private OrderRepository orderrepo;
	@Autowired
	private  WebClient.Builder webclientBuilder;
	@Autowired
	private KafkaTemplate<String,OrderPlacedEvent> kafkatemplate;
	@Autowired
	private ApplicationEventPublisher applicationeventpublisher;
	
	public String placeOrder(OrderRequest orequest) {
		Order o=new Order();
		o.setOrdernum(UUID.randomUUID().toString());
		orequest.getItemsdto()
		.stream().map(OrderItemsdto -> mapTodto(OrderItemsdto));
	
		InventoryResponse[] result=webclientBuilder.build().get()
				.uri("http://inventory-service/inventory",uriBuilder -> uriBuilder.queryParam("name",names).build())
				.retrieve().bodyToMono(InventoryResponse[].class).block();
		
		boolean allProductsInStock=Arrays.stream(result).allMatch(InventoryResponse::inStock);
		if(allProductsInStock) {
			orderrepo.save(o);
			applicationeventpublisher.publishEvent(new OrderPlacedEvent(o.getOrdernum()));
			//kafkatemplate.send("notificationTopic", new OrderPlacedEvent(o.getOrdernum()));
			return "Order Placed Successfully!";
		}else {
			throw new IllegalArgumentException("Product not in stock!");
		}
	
	 
	}
	private OrderItems mapTodto(OrderItemsdto oid) {
		OrderItems oi= new OrderItems();
		oi.setPrice(oid.getPrice());
		oi.setQuantity(oid.getQuantity());
		oi.setName(oid.getName());
		
		return oi;
	}

}
