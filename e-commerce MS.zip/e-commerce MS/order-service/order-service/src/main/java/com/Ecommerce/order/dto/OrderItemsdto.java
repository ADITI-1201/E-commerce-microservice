package com.Ecommerce.order.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OrderItemsdto {
	private long id;
	private long price;
	private Integer quantity;
	private String name;

}
